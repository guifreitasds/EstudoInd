n1 = int(input('Digite o 1° valor: '))
n2 = int(input('Digite o 2° valor: '))

print(f'=======================\nAdição = {n1+n2} \nSubtração = {n1-n2} \nMultiplicação = {n1*n2} \nDivisão = {n1/n2}\n=======================')